<?php
class Lost_page extends CI_Controller{
	function index(){		
		$this->load->view('main/Lost_page');
	}
}
