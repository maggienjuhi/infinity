<?php
class Home extends CI_Controller{
	function index(){		
		//$data['main_content']= 'index/Home';
		$this->load->view('index/Home');
		//redirect('student_profiles');
	}
}
