          <div class="row">
            <div class="col-md-12">
              <div class="box box-info">
                <div class="box-header with-border">
                  <h3 class="box-title">Business cards</h3>
                </div><!-- /.box-header -->

						    <div class="row">
						      <div class="col-md-5">
										<div id="card1">
											<div class="row">
						      			<div class="col-md-5">						
										  		<span><img width="50" height="50" id="img1" src="<?php echo base_url();?>images/photo.jpg" /></span>
													<span class="fa fa-cloud" id="div_below_domain">Domain</span>
													<span class="fa fa-laptop" id="div_below_email">Email</span>
													<span class="fa fa-phone" id="div_below_phone">Phone Number</span>
													<span class="fa fa-ticket" id="div_below_slogan">Slogan</span>
												</div><!-- /.col-->
						      			<div id="div_details" class="col-md-5">
													<h4>Full Names</h4>
													<h3>Position </h3><hr/>
													<span><strong>Company</strong></span>
													<!--<h5><i>Infinity designs ltd </i></h5>
													<span>P.O Box 1234 </span>
													<span>Lion Place Second Floor </span>
													<span>joannjoki.com</span>-->
												</div><!-- /.col-->
											</div><!-- /.row-->
										</div><!-- /.card1-->
										<div class="row">
						      		<div class="col-md-5">	
								         <a class="fa fa-chevron-up" href="<?php echo base_url();?>index.php/business_cards/create/1/">Fill in your details</a>
											</div><!-- /.col-->
										</div><!-- /.row-->
						      </div><!-- /.col -->

						      <div class="col-md-5">
										<div id="card2">
											<div class="row">
						      			<div class="col-md-5">						
										  		<span><img width="50" height="50" id="img1" src="<?php echo base_url();?>images/photo.jpg" /></span>
													<span class="fa fa-cloud" id="div_below_domain">Domain</span>
													<span class="fa fa-laptop" id="div_below_email">Email</span>
													<span class="fa fa-phone" id="div_below_phone">Phone Number</span>
													<span class="fa fa-ticket" id="div_below_slogan">Slogan</span>
												</div><!-- /.col-->
						      			<div id="div_details" class="col-md-5">
													<h4>Full Names</h4>
													<h3>Position </h3><hr/>
													<span><strong>Company</strong></span>
													<!--<h5><i>Infinity designs ltd </i></h5>
													<span>P.O Box 1234 </span>
													<span>Lion Place Second Floor </span>
													<span>joannjoki.com</span>-->
												</div><!-- /.col-->
											</div><!-- /.row-->

										</div><!-- /.card2-->
										<div class="row">
						      		<div class="col-md-5">	
								         <a class="fa fa-chevron-up" href="<?php echo base_url();?>index.php/business_cards/create/2/">Fill in your details</a>
											</div><!-- /.col-->
										</div><!-- /.row-->
						      </div><!-- /.col -->
						    </div><!-- /.row -->

						    <div class="row">
						      <div class="col-md-5">
										<div id="card3">
											<div class="row">
						      			<div class="col-md-5">						
										  		<span><img width="50" height="50" id="img1" src="<?php echo base_url();?>images/photo.jpg" /></span>
													<span class="fa fa-cloud" id="div_below_domain">Domain</span>
													<span class="fa fa-laptop" id="div_below_email">Email</span>
													<span class="fa fa-phone" id="div_below_phone">Phone Number</span>
													<span class="fa fa-ticket" id="div_below_slogan">Slogan</span>
												</div><!-- /.col-->
						      			<div id="div_details" class="col-md-5">
													<h4>Full Names</h4>
													<h3>Position </h3><hr/>
													<span><strong>Company</strong></span>
													<!--<h5><i>Infinity designs ltd </i></h5>
													<span>P.O Box 1234 </span>
													<span>Lion Place Second Floor </span>
													<span>joannjoki.com</span>-->
												</div><!-- /.col-->
											</div><!-- /.row-->
										</div><!-- /.card3-->
										<div class="row">
						      		<div class="col-md-5">	
								         <a class="fa fa-chevron-up" href="<?php echo base_url();?>index.php/business_cards/create/3/">Fill in your details</a>
											</div><!-- /.col-->
										</div><!-- /.row-->
						      </div><!-- /.col -->
						      <div class="col-md-5">
										<div id="card4">
											<div class="row">
						      			<div class="col-md-5">						
										  		<span><img width="50" height="50" id="img1" src="<?php echo base_url();?>images/photo.jpg" /></span>
													<span class="fa fa-cloud" id="div_below_domain">Domain</span>
													<span class="fa fa-laptop" id="div_below_email">Email</span>
													<span class="fa fa-phone" id="div_below_phone">Phone Number</span>
													<span class="fa fa-ticket" id="div_below_slogan">Slogan</span>
												</div><!-- /.col-->
						      			<div id="div_details" class="col-md-5">
													<h4>Full Names</h4>
													<h3>Position </h3><hr/>
													<span><strong>Company</strong></span>
													<!--<h5><i>Infinity designs ltd </i></h5>
													<span>P.O Box 1234 </span>
													<span>Lion Place Second Floor </span>
													<span>joannjoki.com</span>-->
												</div><!-- /.col-->
											</div><!-- /.row-->
										</div><!-- /.card4-->
										<div class="row">
						      		<div class="col-md-5">	
								         <a class="fa fa-chevron-up" href="<?php echo base_url();?>index.php/business_cards/create/4/">Fill in your details</a>
											</div><!-- /.col-->
										</div><!-- /.row-->
						      </div><!-- /.col -->
						    </div><!-- /.row -->


						    <div class="row">
						      <div class="col-md-5">
										<div id="card5">
											<div class="row">
						      			<div class="col-md-5">						
										  		<span><img width="50" height="50" id="img1" src="<?php echo base_url();?>images/photo.jpg" /></span>
													<span class="fa fa-cloud" id="div_below_domain">Domain</span>
													<span class="fa fa-laptop" id="div_below_email">Email</span>
													<span class="fa fa-phone" id="div_below_phone">Phone Number</span>
													<span class="fa fa-ticket" id="div_below_slogan">Slogan</span>
												</div><!-- /.col-->
						      			<div id="div_details" class="col-md-5">
													<h4>Full Names</h4>
													<h3>Position </h3><hr/>
													<span><strong>Company</strong></span>
													<!--<h5><i>Infinity designs ltd </i></h5>
													<span>P.O Box 1234 </span>
													<span>Lion Place Second Floor </span>
													<span>joannjoki.com</span>-->
												</div><!-- /.col-->
											</div><!-- /.row-->
										</div><!-- /.card5-->
										<div class="row">
						      		<div class="col-md-5">	
								         <a class="fa fa-chevron-up" href="<?php echo base_url();?>index.php/business_cards/create/5/">Fill in your details</a>
											</div><!-- /.col-->
										</div><!-- /.row-->
						      </div><!-- /.col -->
						      <div class="col-md-5">
										<div id="card6">
											<div class="row">
						      			<div class="col-md-5">						
										  		<span><img width="50" height="50" id="img1" src="<?php echo base_url();?>images/photo.jpg" /></span>
													<span class="fa fa-cloud" id="div_below_domain">Domain</span>
													<span class="fa fa-laptop" id="div_below_email">Email</span>
													<span class="fa fa-phone" id="div_below_phone">Phone Number</span>
													<span class="fa fa-ticket" id="div_below_slogan">Slogan</span>
												</div><!-- /.col-->
						      			<div id="div_details" class="col-md-5">
													<h4>Full Names</h4>
													<h3>Position </h3><hr/>
													<span><strong>Company</strong></span>
													<!--<h5><i>Infinity designs ltd </i></h5>
													<span>P.O Box 1234 </span>
													<span>Lion Place Second Floor </span>
													<span>joannjoki.com</span>-->
												</div><!-- /.col-->
											</div><!-- /.row-->
										</div><!-- /.card6-->
										<div class="row">
						      		<div class="col-md-5">	
								         <a class="fa fa-chevron-up" href="<?php echo base_url();?>index.php/business_cards/create/6/">Fill in your details</a>
											</div><!-- /.col-->
										</div><!-- /.row-->
						      </div><!-- /.col -->
						    </div><!-- /.row -->


              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
